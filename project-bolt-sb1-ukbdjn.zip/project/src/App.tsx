import React, { useState } from 'react';
import { Brain, CheckCircle2, XCircle, Trophy, RefreshCcw } from 'lucide-react';
import { questions } from './questions';

function App() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState<boolean[]>(new Array(questions.length).fill(false));

  const handleAnswer = (optionIndex: number) => {
    if (answered[currentQuestion]) return;
    
    const newAnswered = [...answered];
    newAnswered[currentQuestion] = true;
    setAnswered(newAnswered);
    setSelectedAnswer(optionIndex);

    if (optionIndex === questions[currentQuestion].correct) {
      setScore(score + 1);
    }
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
      setShowResult(true);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setAnswered(new Array(questions.length).fill(false));
  };

  if (showResult) {
    return (
      <div className="min-h-screen bg-pink-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl p-8 max-w-2xl w-full">
          <div className="flex flex-col items-center gap-4">
            <Trophy className="w-16 h-16 text-pink-500" />
            <h2 className="text-3xl font-bold text-gray-800">Sınav Tamamlandı!</h2>
            <p className="text-xl text-gray-600">
              Toplam Skorunuz: {score} / {questions.length}
            </p>
            <p className="text-lg text-gray-500">
              Başarı Oranı: {((score / questions.length) * 100).toFixed(1)}%
            </p>
            <button
              onClick={resetQuiz}
              className="mt-4 flex items-center gap-2 bg-pink-500 text-white px-6 py-3 rounded-lg hover:bg-pink-600 transition-colors"
            >
              <RefreshCcw className="w-5 h-5" />
              Tekrar Başla
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-pink-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl p-8 max-w-3xl w-full">
        <div className="flex items-center gap-3 mb-6">
          <Brain className="w-8 h-8 text-pink-500" />
          <h1 className="text-2xl font-bold text-gray-800">
            Adli Bilimler Etik Standartlar Sınavı
          </h1>
        </div>

        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-500">
              Soru {currentQuestion + 1} / {questions.length}
            </span>
            <span className="text-sm font-medium text-pink-500">
              Skor: {score}
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-pink-500 rounded-full h-2 transition-all duration-300"
              style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        <div className="mb-6">
          <h2 className="text-xl font-semibold text-gray-700 mb-4">
            {questions[currentQuestion].question}
          </h2>
          <div className="space-y-3">
            {questions[currentQuestion].options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswer(index)}
                disabled={answered[currentQuestion]}
                className={`w-full text-left p-4 rounded-lg transition-all ${
                  selectedAnswer === index
                    ? index === questions[currentQuestion].correct
                      ? 'bg-green-100 border-2 border-green-500'
                      : 'bg-red-100 border-2 border-red-500'
                    : 'bg-gray-50 hover:bg-pink-50 border-2 border-transparent'
                } ${answered[currentQuestion] && index === questions[currentQuestion].correct
                  ? 'bg-green-100 border-2 border-green-500'
                  : ''
                }`}
              >
                <div className="flex items-center gap-3">
                  {answered[currentQuestion] && (
                    <>
                      {index === questions[currentQuestion].correct ? (
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                      ) : selectedAnswer === index ? (
                        <XCircle className="w-5 h-5 text-red-500" />
                      ) : null}
                    </>
                  )}
                  <span className="text-gray-700">{option}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {answered[currentQuestion] && (
          <button
            onClick={nextQuestion}
            className="w-full bg-pink-500 text-white py-3 rounded-lg hover:bg-pink-600 transition-colors"
          >
            {currentQuestion === questions.length - 1 ? 'Sonuçları Gör' : 'Sonraki Soru'}
          </button>
        )}
      </div>
    </div>
  );
}

export default App;