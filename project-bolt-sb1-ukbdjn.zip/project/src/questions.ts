export interface Question {
  id: number;
  question: string;
  options: string[];
  correct: number;
}

export const questions: Question[] = [
  {
    id: 1,
    question: "Aşağıdakilerden hangisi adli bilimlerin en doğru tanımıdır?",
    options: [
      "İnsan davranışı ve psikolojisini inceleyen bilimler.",
      "Ceza ve adalet sisteminde kanunlara uygun, bilimsel uygulamalarla adalete hizmet eden bilimler bütünü.",
      "Hukuki meselelerle ilgisi olmayan doğal olayları inceleyen bilimler.",
      "Tıbbi tedavilere odaklanan bilimsel bir alan.",
      "Mahkemede sanıkların savunulmasıyla ilgilenen bilimler."
    ],
    correct: 1
  },
  {
    id: 2,
    question: "Aşağıdakilerden hangisi adli bilimlerde anahtar terimlerden biri DEĞİLDİR?",
    options: [
      "Etik",
      "Fiziksel Delil",
      "Delil Teslim Zinciri",
      "Adli Muhasebe",
      "Tanıklık"
    ],
    correct: 3
  },
  {
    id: 3,
    question: "Suç bağlamında adli bilimlerin birincil önemi nedir?",
    options: [
      "Her zaman bir şüphelinin suçlu olduğunu kanıtlamak.",
      "Masumiyetin ortaya çıkarılmasına yardımcı olmak.",
      "Kanıtları manipüle ederek mahkûmiyeti sağlamak.",
      "Mahkemede avukatların yerini almak.",
      "Cezanın ağırlığını belirlemek."
    ],
    correct: 1
  },
  {
    id: 4,
    question: "Adli bilimlerde \"tarafsızlık\" kavramı en iyi nasıl tanımlanır?",
    options: [
      "Adaleti sağlamak için bir tarafı diğerine tercih etmek.",
      "Dil, din, ırk veya siyaset gözetmeksizin önyargısız ve adil olmak.",
      "Ceza davalarında savcılığı desteklemek.",
      "Sanığın beraatini sağlamak.",
      "Hukuki meselelere hiç karışmamak."
    ],
    correct: 1
  },
  {
    id: 5,
    question: "Adli bilimlerde \"delil teslim zinciri\" nedir?",
    options: [
      "Şüphelileri kelepçelemek için kullanılan fiziksel zincir.",
      "Fiziksel ve elektronik delillerin toplanmasından analizine kadar izlediği kronolojik yol.",
      "Polis ile şüphelinin ailesi arasındaki velayet anlaşması.",
      "Hukuki bir davadaki duruşmaların sıralaması.",
      "Laboratuvardaki adli bilimcilerin hiyerarşisi."
    ],
    correct: 1
  },
  {
    id: 6,
    question: "Aşağıdakilerden hangisi bir adli bilimcinin sorumluluklarından biri DEĞİLDİR?",
    options: [
      "Prosedürleri takip etmek ve delil toplama kurallarına uymak.",
      "Tarafsızlığını korumak.",
      "Mahkemede bir tarafı desteklemek için bilgi sağlamak.",
      "Yasal ve bilimsel sınırlar içinde kalmak.",
      "Yeterli eğitim ve öğretime sahip olmak."
    ],
    correct: 2
  },
  {
    id: 7,
    question: "Metinde bahsedilen, dünyanın en büyük adli bilimler kuruluşu hangisidir?",
    options: [
      "Interpol",
      "Dünya Sağlık Örgütü (WHO)",
      "American Academy of Forensic Science (AAFS)",
      "Uluslararası Ceza Mahkemesi (ICC)",
      "Birleşmiş Milletler Uyuşturucu ve Suç Ofisi (UNODC)"
    ],
    correct: 2
  },
  {
    id: 8,
    question: "Fiziksel delillerin analizinde aşağıdaki etik kurallardan hangisi doğrudur?",
    options: [
      "Alanda kabul görmüş olsun veya olmasın, mevcut herhangi bir yöntemi kullanmak.",
      "Analiz sırasında yalnızca uzmanlık alanında kabul edilmiş metodolojiyi kullanmak.",
      "Sonuçları hızlandırmak için standart prosedürleri göz ardı etmek.",
      "Sonuçları iyileştirmek için ekipmanı değiştirmek.",
      "İstenilen sonucu desteklemek için bulguları abartmak."
    ],
    correct: 1
  },
  {
    id: 9,
    question: "Adli bilimlerde standartlaştırma neden önemlidir?",
    options: [
      "Tüm bilim insanlarının aynı şekilde düşünmesini sağlamak için.",
      "Adli hizmetlerde tekel oluşturmak için.",
      "Fiziksel delillerin toplanması, incelenmesi ve analizini standartlaştırarak tutarlı ve güvenilir sonuçlar elde etmek için.",
      "Adli soruşturmaların maliyetini azaltmak için.",
      "Adli araştırmaların kapsamını sınırlamak için."
    ],
    correct: 2
  },
  {
    id: 10,
    question: "Adli bilimlerde \"koruma\" terimi neyi ifade eder?",
    options: [
      "Delillerin güvenli ve sağlam tutulmasını.",
      "Analizden sonra delillerin imha edilmesini.",
      "Bir şüphelinin mahkûm edilme sürecini.",
      "Laboratuvar ekipmanlarının bakımını.",
      "Adli bilimcinin itibarının korunmasını."
    ],
    correct: 0
  },
  {
    id: 11,
    question: "Fiziksel delillerin raporlanmasında aşağıdaki davranışlardan hangisi etik dışıdır?",
    options: [
      "Analiz sonuçlarını doğru bir şekilde raporlamak.",
      "Raporda belirsiz terimlerden kaçınmak.",
      "Başka bir bilim insanının çalışmalarını kendi çalışmasıymış gibi raporlamak.",
      "Sonuçları ne ifade ediyorsa onunla sınırlamak.",
      "Fotoğraf ve belgeleri kabul edilen standartlarda oluşturmak."
    ],
    correct: 2
  },
  {
    id: 12,
    question: "Bir adli bilimci, bulgularının kendi uzmanlık alanının dışında olduğunu fark ederse ne yapmalıdır?",
    options: [
      "Bulguları raporlayıp yorumlamaya devam etmeli.",
      "Bulguları tamamen görmezden gelmeli.",
      "Nitelikli bir uzmana danışmalı veya kendi uzmanlık alanını aşan sonuçlardan kaçınmalı.",
      "En olası yorumu tahmin etmeli.",
      "Verileri kendi uzmanlık alanına uydurmak için değiştirmeli."
    ],
    correct: 2
  },
  {
    id: 13,
    question: "Bir adli bilimcinin temel fonksiyonları arasında hangisi yer alır?",
    options: [
      "Fiziksel delilleri analiz etmek, yorumlamak ve raporlamak.",
      "Mahkemede şüphelileri kovuşturmak.",
      "Davalarda sanıkları savunmak.",
      "Ceza adaletine ilişkin yasalar yapmak.",
      "Davalarda jüri üyesi olarak görev yapmak."
    ],
    correct: 0
  },
  {
    id: 14,
    question: "Fiziksel delillerin yorumlanmasında etik bir değerlendirme nedir?",
    options: [
      "Bilimsel gerçekleri kişisel görüşlerle karıştırmak.",
      "Bulguları bir hipotezi desteklemek için abartmak.",
      "Yorumları bilimsel sonuçlara dayandırmak ve kişisel önyargılardan kaçınmak.",
      "Beklenen sonucu desteklemeyen verileri görmezden gelmek.",
      "Verilerdeki sınırlamaları göz ardı etmek."
    ],
    correct: 2
  },
  {
    id: 15,
    question: "Adli bilimlerde \"tanıklık\" terimi en iyi nasıl tanımlanır?",
    options: [
      "Dava hakkında yapılan sıradan bir konuşma.",
      "Mahkemede yemin altında bulunan bir tanığın ifadesi veya beyanı.",
      "Bir dergiye sunulan yazılı rapor.",
      "Meslektaşlarla paylaşılan gayri resmi bir görüş.",
      "Dava hakkında basın açıklaması."
    ],
    correct: 1
  },
  {
    id: 16,
    question: "Başka bir bilim insanı tarafından daha önce incelenen delillerin yeniden incelenmesi ne zaman kabul edilebilirdir?",
    options: [
      "Sadece ilk bilim insanı kabul ederse.",
      "Herhangi bir itiraz yoktur, ancak farklılıklar dava ilerlemeden önce makul bir şekilde tartışılmalıdır.",
      "Hiçbir koşulda kabul edilemez.",
      "Sadece mahkeme tarafından emredilirse.",
      "Sadece önceki analiz geçersiz ise."
    ],
    correct: 1
  },
  {
    id: 17,
    question: "Adli bilimciler arasında mesleki nezaket açısından aşağıdaki davranışlardan hangisi etik dışıdır?",
    options: [
      "Meslektaşları yeni metodolojiler hakkında bilgilendirmek.",
      "Yanlış olduğu kanıtlanmadıkça meslektaşların görüşlerine saygı duymak.",
      "Meslektaşların ifadelerini, sonuçlarını, raporlarını veya çalışmalarını çarpıtmak veya yanlış temsil etmeye çalışmak.",
      "Avukatlara başka bir uzman görüşü alınmasını iyi niyetle tavsiye etmek.",
      "Geçersiz veya güvenilir olmayan metodolojiler hakkında meslektaşını bilgilendirmek."
    ],
    correct: 2
  },
  {
    id: 18,
    question: "Fiziksel delillerin raporlanmasında aşağıdakilerden hangisi etik bir kavram DEĞİLDİR?",
    options: [
      "Kişisel çıkar veya kazancın bir raporu çarpıtmaması.",
      "Kendinize ait olmayan sonuçları asla raporlamamak.",
      "Analizlerden elde edilen sonuçların ifade ettiği anlamı sınırlandırmak.",
      "Bulguları vurgulamak için sansasyonel veya abartılı dil kullanmak.",
      "Yanıltıcı veya belirsiz terimlerden kaçınmak."
    ],
    correct: 3
  },
  {
    id: 19,
    question: "Bir adli bilimci, paylaşılan bir davada meslektaşının verileri tahrif ettiğini öğrenirse ne yapmalıdır?",
    options: [
      "Çatışmadan kaçınmak için görmezden gelmeli.",
      "Yöneticisine veya amirine rapor etmelidir.",
      "Meslektaşına yardım ederek durumu örtbas etmeli.",
      "Kanıt olmadan meslektaşını halka açık şekilde suçlamalı.",
      "Dava bitene kadar bekleyip sonra bahsetmeli."
    ],
    correct: 1
  },
  {
    id: 20,
    question: "Örnek vakada, bir savunma avukatı DNA kanıtlarının savunmasında hata yapar ve davayı kesin olarak kaybedecektir. Adli bilimcinin etik yükümlülüğü nedir?",
    options: [
      "Her iki taraf da bulguları uygun gördüğü gibi kullanacağı için hiçbir şey yapmamalı.",
      "Bir bilim insanı olarak yanıltıcı veya hatalı ifadeye dayanamayacağı için avukatı düzeltmeli.",
      "Avukatın hatasını medya ile paylaşmalı.",
      "Savcılığın hatadan faydalanmasına yardımcı olmalı.",
      "Yanlış kullanımını önlemek için delili yok etmeli."
    ],
    correct: 1
  },
  {
    id: 21,
    question: "Fiziksel delillerin analizinde etik kuralların ihlali olan davranış hangisidir?",
    options: [
      "Analiz için standart, kabul görmüş yöntemleri kullanmak.",
      "Güvenilir ve doğru ekipman kullanmak.",
      "Yanlış sonuçlar geliştirmek için aşırı işlem uygulamak.",
      "Bulguları doğru yorumlamak ve değerlendirmek.",
      "Tüm prosedürleri doğru bir şekilde belgelemek."
    ],
    correct: 2
  },
  {
    id: 22,
    question: "Raporlarda sansasyonel dil kullanmaktan kaçınmanın nedeni nedir?",
    options: [
      "Raporun çok ilgi çekici olmasını önlemek için.",
      "Mahkemeyi yanıltmamak ve açıklık ve tarafsızlığı sağlamak için.",
      "Hukuki belgelerin belirli kelimeleri yasaklaması nedeniyle.",
      "Gizli bir atmosferi sürdürmek için.",
      "Raporun uzunluğunu azaltmak için."
    ],
    correct: 1
  },
  {
    id: 23,
    question: "Metinde bahsedilen Masumiyet Projesi'nin amacı nedir?",
    options: [
      "Suçluların mahkûmiyetini desteklemek.",
      "DNA testi yoluyla yanlış mahkûm edilen bireyleri aklamak ve ceza adalet sistemini reforme etmek.",
      "Yeni adli teknolojiler geliştirmek.",
      "Savcılara adli bilim eğitimi vermek.",
      "Adli laboratuvarlara fon sağlamak."
    ],
    correct: 1
  },
  {
    id: 24,
    question: "Fiziksel delillerin yorumlanmasında etik kurallara uymaya bir örnek hangisidir?",
    options: [
      "Uzmanlık alanının ötesinde sonuçlar bildirmek.",
      "Bilimsel gerçekleri kişisel görüşlerle etkilemek.",
      "Yorumları bilimsel sonuçlara dayandırmak ve kişisel önyargılardan kaçınmak.",
      "Gri alanları görmezden gelip sadece net delillere odaklanmak.",
      "Yetersiz veriyle kesin sonuçlar çıkarmak."
    ],
    correct: 2
  },
  {
    id: 25,
    question: "Adli bilimcilerin yeterli eğitim ve öğretime sahip olmaları neden önemlidir?",
    options: [
      "Mahkemede unvanlarıyla etkilemek için.",
      "Delilleri yasal ve bilimsel standartlar içinde doğru bir şekilde analiz etmek, yorumlamak ve raporlamak için.",
      "Daha yüksek maaşlar almak için.",
      "Diğer bilim insanlarıyla rekabet etmek için.",
      "Karmaşık raporlar yazmak için."
    ],
    correct: 1
  },
  {
    id: 26,
    question: "Bilirkişilik hizmetleri için ücretlendirme konusunda etik duruş nedir?",
    options: [
      "Uzmanlar hizmetlerini ücretsiz sunmalıdır.",
      "Uzmanlar fahiş ücretler talep etmelidir.",
      "Uzmanlar hizmetleri için makul bir ücret belirlemelidir.",
      "Uzmanlar ücretlerini mahkemenin belirlemesine izin vermelidir.",
      "Uzmanlar dava sonucuna göre ücret talep etmelidir."
    ],
    correct: 2
  },
  {
    id: 27,
    question: "Bir adli bilimci, başka bir bilim insanının metodolojisine katılmadığında kabul edilebilir olmayan yaklaşım hangisidir?",
    options: [
      "Geçersiz veya güvenilir olmayan metodolojiler hakkında meslektaşını bilgilendirmek.",
      "Meslektaşının çalışmasını kötülemek için yanlış temsil etmek.",
      "Yanlış olduğunu kanıtlayamadıkça meslektaşının görüşlerine saygı duymak.",
      "İhtilafları çözmek için farklılıkları tartışmak.",
      "Gerekirse avukatlara iyi niyetle bilgi vermek."
    ],
    correct: 1
  },
  {
    id: 28,
    question: "Adli bilimlerde etiğin birincil odak noktası nedir?",
    options: [
      "Adli laboratuvarların kârını maksimize etmek.",
      "Adli bilimcilerin prestijini artırmak.",
      "Eylemlerin doğruluğu ve geçerliliği ile ilgili olarak doğru ve adil insan davranışını sağlamak.",
      "Kişisel kariyer hedeflerini ilerletmek.",
      "Hukuki prosedürleri basitleştirmek."
    ],
    correct: 2
  },
  {
    id: 29,
    question: "Fiziksel delillerin etik dışı bir şekilde değiştirilmesine örnek hangisidir?",
    options: [
      "Delilleri orijinal haliyle korumak.",
      "Delilleri bir hipoteze uydurmak için değiştirmek.",
      "Delilleri analiz etmek için kabul edilmiş yöntemler kullanmak.",
      "Delil teslim zincirini düzgün bir şekilde belgelemek.",
      "Ölçümler için kalibre edilmiş ekipman kullanmak."
    ],
    correct: 1
  },
  {
    id: 30,
    question: "O.J. Simpson davasında aşağıdakilerden hangisi bahsedilen etik sorunlardan biri DEĞİLDİR?",
    options: [
      "Olay yeri incelemenin hatalı yapılması.",
      "Kan bulgusunun üç saatten fazla bir süre sıcak bir minibüste kalması.",
      "Delil teslim zincirinde kan bulgusunun eksik olması.",
      "Adli bilimcinin tarafsız tanıklığı.",
      "Dedektif Marc Furman'ın ırkçı yaklaşımı."
    ],
    correct: 3
  },
  {
    id: 31,
    question: "Fiziksel delillerin yorumlanmasında \"gri alanlar\" neyi ifade eder?",
    options: [
      "Delillerin eksik olduğu alanlar.",
      "Yorumların her iki tarafı da eşit derecede desteklediği ve detaylı açıklama gerektiren durumlar.",
      "Gri renkli vakaları.",
      "Net ve kesin delillerin olduğu durumlar.",
      "Adli bilimle ilgisi olmayan hukuki meseleler."
    ],
    correct: 1
  },
  {
    id: 32,
    question: "Adli analizde yalnızca geçerli, güvenilir, standart yöntemlerin kullanılması neden önemlidir?",
    options: [
      "Zaman ve kaynak tasarrufu sağlamak için.",
      "Sonuçların yasal olarak kabul edilebilir ve bilimsel olarak sağlam olmasını sağlamak için.",
      "Diğer bilim insanlarının yöntemleri sorgulamasını önlemek için.",
      "Yöntemleri halktan gizli tutmak için.",
      "Müşterileri gelişmiş tekniklerle etkilemek için."
    ],
    correct: 1
  },
  {
    id: 33,
    question: "Adli bilimcinin mahkemede rolü en iyi nasıl tanımlanır?",
    options: [
      "Savcılığın savunucusu olarak hareket etmek.",
      "Savunmanın savunucusu olarak hareket etmek.",
      "Mahkemeye yardımcı olmak için tarafsız, objektif bilimsel bilgi sağlamak.",
      "Sanığın suçlu veya masum olduğuna karar vermek.",
      "Jüriye bilimsel yöntemler konusunda eğitim vermek."
    ],
    correct: 2
  },
  {
    id: 34,
    question: "Bir adli bilimci, önceki tanıklığında bir hata keşfederse ne yapmalıdır?",
    options: [
      "Utançtan kaçınmak için görmezden gelmeli.",
      "Mahkemeyi bilgilendirip hatayı mümkün olan en kısa sürede düzeltmeli.",
      "Hatanın suçunu başkasına atmalı.",
      "Karar verilene kadar beklemeli.",
      "Hatanın gizlenmesi için kayıtları değiştirmeli."
    ],
    correct: 1
  },
  {
    id: 35,
    question: "Adli bilimlerde bilim ve hukuk arasındaki ilişkiyle ilgili aşağıdaki ifadelerden hangisi doğrudur?",
    options: [
      "Bilim ve hukuk aynı amaç ve yöntemlere sahiptir.",
      "Bilim doğal olaylarla, hukuk insan yapımı kurallar ve düzenlemelerle ilgilenir; adli bilimciler her ikisini de birleştirir.",
      "Hukuk, adli soruşturmalarda bilimden üstündür.",
      "Hukukî meselelerde bilime gerek yoktur.",
      "Adli bilimciler sadece hukuki konulara odaklanmalı, bilimsel yöntemlerle ilgilenmemelidir."
    ],
    correct: 1
  }
];